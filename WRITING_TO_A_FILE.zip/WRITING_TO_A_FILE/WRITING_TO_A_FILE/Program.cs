﻿using System;
using System.IO;


namespace WRITING_TO_A_FILE
{
    class Program
    {
        public Program()
        {
            Writer();
            Reader();
        }

        public void Writer()
        {
            try 
            {
                StreamWriter SW = new StreamWriter("C:\\Users\\KHOTSO SEKANTSI\\Desktop\\MINE.txt", true);

                Console.WriteLine("PLEASE WRITE NAME : ");
                string name = Console.ReadLine();
                Console.WriteLine("PLEASE WRITE SURNAME : ");
                string surname = Console.ReadLine();

                SW.WriteLine("name: " + name);
                SW.WriteLine("surname: " + surname);
                SW.Close();
            }
            catch (IOException E)
            {
                Console.WriteLine("");
            }
        }
        private void Reader()
        {
            try
            {
                StreamReader SR = new StreamReader("C:\\Users\\KHOTSO SEKANTSI\\Desktop\\MINE.txt");

                while (SR.Peek() > -1)
                {
                    Console.WriteLine(SR.ReadLine());
                }
                Console.WriteLine("reading complete");
                SR.Close();
            }
            catch (IOException E)
            {
               
            }
        }

        static void Main(string[] args)
        {
            Program sekantsi = new Program();
        }
    }
}
