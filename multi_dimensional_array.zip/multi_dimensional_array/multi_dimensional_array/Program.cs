﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace multi_dimensional_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] HKR = {200, 170, 70, 20, 120, 95, 60};
            int[] LKR = {70, 50, 140, 100, 99, 120, 100 };
            int [,] milleage = new int [7, 2];
 
            for(int i = 0; i < 7; i++)
            {
                milleage[i, 0] = HKR[i];
                milleage[i, 1] = LKR[i];
            }
            for(int i = 0; i < 7; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    Console.Write( " \t " + milleage[i, j]);
                }
                Console.WriteLine("  ");
            }
        }
    }
}
