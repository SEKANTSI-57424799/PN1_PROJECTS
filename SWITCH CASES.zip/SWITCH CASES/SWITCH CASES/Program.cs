﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SWITCH_CASES
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine( "THE SWITCH CASE PRACTICAL" );

            int days;

            Console.WriteLine(" PLEASE ENTER A DAY ");
            days = Convert.ToInt32(Console.ReadLine());

            switch (days) {
                case 1:
                    Console.WriteLine(" MONDAY ");
                    break;

                case 2:
                    Console.WriteLine(" TUESDAY ");
                    break;
                case 3:
                    Console.WriteLine(" WEDNESDAY ");
                    break;
                case 4:
                    Console.WriteLine(" THURSDAY ");
                    break;
                case 5:
                    Console.WriteLine(" FRIDAY ");
                    break;
                case 6:
                    Console.WriteLine(" SATURDAY ");
                    break;
                case 7:
                    Console.WriteLine(" SUNDAY ");
                    break;
                default:
                    Console.WriteLine(" INVALID ");
                    break;
            }
        }
    }
}
