﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SHAPES
{
    class Program
    {
        static void Main(string[] args)
        {
            int rows;

            Console.WriteLine(" PLEASE ENTER NUMBER OF LINES ");
            rows = Convert.ToInt32(Console.ReadLine());

            for (int i=1; i <= rows; ++i)
            {
                for(int j=1; j<=i; ++j)
                {
                    Console.Write("*");
                }
                Console.Write("\n");
            }



        }
    }
}
