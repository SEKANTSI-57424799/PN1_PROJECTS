﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" HELLO WORLD");

            Console.WriteLine("ENTER YOUR AGE");
            int age= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("you are " + age);


            if (age < 45)
            {
                Console.WriteLine("YOUR STILL YOUNG");
            }
            else {
                Console.WriteLine("you are old");
            }

        }
    }
}
