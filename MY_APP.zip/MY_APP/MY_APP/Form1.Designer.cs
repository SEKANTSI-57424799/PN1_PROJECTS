﻿namespace MY_APP
{
    partial class frmNewapp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbc = new System.Windows.Forms.TabControl();
            this.tbCourse = new System.Windows.Forms.TabPage();
            this.tbContacts = new System.Windows.Forms.TabPage();
            this.tbResults = new System.Windows.Forms.TabPage();
            this.gbNames = new System.Windows.Forms.GroupBox();
            this.lblfirst = new System.Windows.Forms.Label();
            this.lblSecond = new System.Windows.Forms.Label();
            this.lblThird = new System.Windows.Forms.Label();
            this.txtFirst = new System.Windows.Forms.TextBox();
            this.txtSecond = new System.Windows.Forms.TextBox();
            this.txtThird = new System.Windows.Forms.TextBox();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnCourse = new System.Windows.Forms.Button();
            this.tbc.SuspendLayout();
            this.tbCourse.SuspendLayout();
            this.tbContacts.SuspendLayout();
            this.gbNames.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbc
            // 
            this.tbc.Controls.Add(this.tbContacts);
            this.tbc.Controls.Add(this.tbCourse);
            this.tbc.Controls.Add(this.tbResults);
            this.tbc.Location = new System.Drawing.Point(1, 0);
            this.tbc.Name = "tbc";
            this.tbc.SelectedIndex = 0;
            this.tbc.Size = new System.Drawing.Size(480, 349);
            this.tbc.TabIndex = 0;
            // 
            // tbCourse
            // 
            this.tbCourse.BackColor = System.Drawing.Color.Aqua;
            this.tbCourse.Controls.Add(this.btnCourse);
            this.tbCourse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCourse.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbCourse.Location = new System.Drawing.Point(4, 22);
            this.tbCourse.Name = "tbCourse";
            this.tbCourse.Padding = new System.Windows.Forms.Padding(3);
            this.tbCourse.Size = new System.Drawing.Size(472, 323);
            this.tbCourse.TabIndex = 1;
            this.tbCourse.Text = "Course Details";
            // 
            // tbContacts
            // 
            this.tbContacts.BackColor = System.Drawing.Color.Azure;
            this.tbContacts.Controls.Add(this.gbNames);
            this.tbContacts.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbContacts.ForeColor = System.Drawing.Color.MidnightBlue;
            this.tbContacts.Location = new System.Drawing.Point(4, 22);
            this.tbContacts.Name = "tbContacts";
            this.tbContacts.Padding = new System.Windows.Forms.Padding(3);
            this.tbContacts.Size = new System.Drawing.Size(472, 323);
            this.tbContacts.TabIndex = 0;
            this.tbContacts.Text = "Contacts Details";
            this.tbContacts.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tbResults
            // 
            this.tbResults.Location = new System.Drawing.Point(4, 22);
            this.tbResults.Name = "tbResults";
            this.tbResults.Size = new System.Drawing.Size(472, 323);
            this.tbResults.TabIndex = 2;
            this.tbResults.Text = "Previous Results";
            this.tbResults.UseVisualStyleBackColor = true;
            // 
            // gbNames
            // 
            this.gbNames.BackColor = System.Drawing.Color.Aqua;
            this.gbNames.Controls.Add(this.btnFirst);
            this.gbNames.Controls.Add(this.txtThird);
            this.gbNames.Controls.Add(this.txtSecond);
            this.gbNames.Controls.Add(this.txtFirst);
            this.gbNames.Controls.Add(this.lblThird);
            this.gbNames.Controls.Add(this.lblSecond);
            this.gbNames.Controls.Add(this.lblfirst);
            this.gbNames.ForeColor = System.Drawing.Color.Red;
            this.gbNames.Location = new System.Drawing.Point(3, 3);
            this.gbNames.Name = "gbNames";
            this.gbNames.Size = new System.Drawing.Size(469, 222);
            this.gbNames.TabIndex = 0;
            this.gbNames.TabStop = false;
            this.gbNames.Text = "NAMES";
            // 
            // lblfirst
            // 
            this.lblfirst.AutoSize = true;
            this.lblfirst.ForeColor = System.Drawing.Color.Navy;
            this.lblfirst.Location = new System.Drawing.Point(6, 33);
            this.lblfirst.Name = "lblfirst";
            this.lblfirst.Size = new System.Drawing.Size(81, 16);
            this.lblfirst.TabIndex = 0;
            this.lblfirst.Text = "First Label";
            this.lblfirst.Click += new System.EventHandler(this.lblfirst_Click);
            // 
            // lblSecond
            // 
            this.lblSecond.AutoSize = true;
            this.lblSecond.ForeColor = System.Drawing.Color.Navy;
            this.lblSecond.Location = new System.Drawing.Point(6, 61);
            this.lblSecond.Name = "lblSecond";
            this.lblSecond.Size = new System.Drawing.Size(104, 16);
            this.lblSecond.TabIndex = 1;
            this.lblSecond.Text = "Second Label";
            this.lblSecond.Click += new System.EventHandler(this.lblSecond_Click);
            // 
            // lblThird
            // 
            this.lblThird.AutoSize = true;
            this.lblThird.ForeColor = System.Drawing.Color.Navy;
            this.lblThird.Location = new System.Drawing.Point(6, 89);
            this.lblThird.Name = "lblThird";
            this.lblThird.Size = new System.Drawing.Size(87, 16);
            this.lblThird.TabIndex = 2;
            this.lblThird.Text = "Third Label";
            // 
            // txtFirst
            // 
            this.txtFirst.Location = new System.Drawing.Point(125, 33);
            this.txtFirst.Name = "txtFirst";
            this.txtFirst.Size = new System.Drawing.Size(225, 22);
            this.txtFirst.TabIndex = 3;
            // 
            // txtSecond
            // 
            this.txtSecond.Location = new System.Drawing.Point(125, 62);
            this.txtSecond.Name = "txtSecond";
            this.txtSecond.Size = new System.Drawing.Size(225, 22);
            this.txtSecond.TabIndex = 4;
            // 
            // txtThird
            // 
            this.txtThird.Location = new System.Drawing.Point(125, 89);
            this.txtThird.Name = "txtThird";
            this.txtThird.Size = new System.Drawing.Size(225, 22);
            this.txtThird.TabIndex = 5;
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(125, 118);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(225, 23);
            this.btnFirst.TabIndex = 6;
            this.btnFirst.Text = "First Button";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnCourse
            // 
            this.btnCourse.Location = new System.Drawing.Point(35, 32);
            this.btnCourse.Name = "btnCourse";
            this.btnCourse.Size = new System.Drawing.Size(221, 23);
            this.btnCourse.TabIndex = 0;
            this.btnCourse.Text = "WAITING FOR NAME";
            this.btnCourse.UseVisualStyleBackColor = true;
            //this.btnCourse.Click += new System.EventHandler(this.btnCourse_Click);
            // 
            // frmNewapp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(480, 346);
            this.Controls.Add(this.tbc);
            this.Name = "frmNewapp";
            this.Text = "New Application";
            this.Load += new System.EventHandler(this.frmNewapp_Load);
            this.tbc.ResumeLayout(false);
            this.tbCourse.ResumeLayout(false);
            this.tbContacts.ResumeLayout(false);
            this.gbNames.ResumeLayout(false);
            this.gbNames.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbc;
        private System.Windows.Forms.TabPage tbContacts;
        private System.Windows.Forms.TabPage tbCourse;
        private System.Windows.Forms.TabPage tbResults;
        private System.Windows.Forms.GroupBox gbNames;
        private System.Windows.Forms.Label lblThird;
        private System.Windows.Forms.Label lblSecond;
        private System.Windows.Forms.Label lblfirst;
        private System.Windows.Forms.TextBox txtThird;
        private System.Windows.Forms.TextBox txtSecond;
        private System.Windows.Forms.TextBox txtFirst;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnCourse;

    }
}

