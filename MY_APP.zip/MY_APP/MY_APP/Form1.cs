﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MY_APP
{
    public partial class frmNewapp : Form
    {
        public frmNewapp()
        {
            InitializeComponent();
        }

        private void frmNewapp_Load(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void lblfirst_Click(object sender, EventArgs e)
        {
            if (lblThird.Text == "GADAFFI")
            {
                lblThird.Text = "Third Label";
            }
            else
            {
                lblThird.Text = "GADAFFI";
            }
        }

        private void lblSecond_Click(object sender, EventArgs e)
        {
            lblThird.Text = txtFirst.Text + " " + txtSecond.Text;
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            txtThird.Text = txtFirst.Text + " " + txtSecond.Text;
            btnCourse.Text = txtFirst.Text + " " + txtSecond.Text;
            btnCourse.Enabled = false;
            txtThird.Enabled = false;
            txtThird.BackColor = Color.Azure;
        }

    }
}
