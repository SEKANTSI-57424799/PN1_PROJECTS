﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STANDING_CHARGE
{
    class Program
    {
        static void Main(string[] args)
        {
            int day_charge = 500;
            double hmr = 5.95;
            double lmr = 2.95;
         
            int[] HKM = {49, 70, 200, 30, 290};
            int[] LKM = { 150, 200, 70, 120, 140};
            
            double[] DC = new double[HKM.Length];
            double WEEKLY_CHARGE=0;
            for (int counter = 0; counter < HKM.Length; counter++) 
            {
                DC[counter] = hmr * HKM[counter] + lmr * LKM[counter] + day_charge;
            }

            for (int counter = 0; counter < HKM.Length; counter++)
            {
                Console.WriteLine("THE DAILY CHARGE FOR DAY{1} IS:{0} ",DC[counter],counter+1);
                    WEEKLY_CHARGE= DC[0]+DC[1]+DC[2]+DC[3]+DC[4];
            }
            Console.WriteLine("THE TOTAL CHARGE IS: " + WEEKLY_CHARGE);
        }
    }
}
