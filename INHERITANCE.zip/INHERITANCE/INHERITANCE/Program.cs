﻿using System;

namespace INHERITANCE
{
    class Program
    {
        static void Main(string[] args)
        {
            FullTimeEmployee FTE = new FullTimeEmployee();
            FTE.first_name = "TEBELLO";
            FTE.last_name = "MPHAROANE";
            FTE.email = "ntebe@gmail.ac.bw";
            FTE.yearly_salary = 500000;

            FTE.DisplayFirstName();
            FTE.DisplaySalary();

            PartTimeEmployee PTE = new PartTimeEmployee();
            PTE.first_name = "TEBOHO";
            PTE.last_name = "FAKO";
            PTE.email = "stebo@gmail.ac.bw";
            PTE.hourly_salary = 5000;

            PTE.DisplayFirstName();
            PTE.DisplaySalary();
        }
    }
    public class EMPLOYEE 
    {
        public string first_name;
        public string last_name;
        public string email;

        public void DisplayFirstName() 
        {
            Console.WriteLine("THE FULL DETAILS OF THE EMPLOYEE ARE: ");
            Console.WriteLine("NAME: " + first_name);
            Console.WriteLine("SURNAME: " + last_name);
            Console.WriteLine("EMAIL: " + email);
        }
    }
    public class PartTimeEmployee : EMPLOYEE
    {
        public float hourly_salary;

        public void DisplaySalary()
        {
            Console.WriteLine("THE SALARY IS: " + hourly_salary);
        }
    }
    public class FullTimeEmployee : EMPLOYEE
    {
        public float yearly_salary;
        public void DisplaySalary()
        {
            Console.WriteLine("THE SALARY IS: " + yearly_salary);
        }
    }
}
