﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // BOXES DONE INDIVIDUALLY WITHOUT ARRAYS:

            box mybox1 = new box();
                mybox1.depth = 20;
                mybox1.length = 50;
                mybox1.width = 10;
                mybox1.Volume();
                    Console.WriteLine("THE VOLUME OF BOX ONE IS: " + mybox1.volume);
            box mybox2 = new box();
                mybox2.length = 25;
                mybox2.width = 30;
                mybox2.depth = 25;
                mybox2.Volume();
                    Console.WriteLine("THE VOLUME OF BOX TWO IS: " + mybox2.volume);

            // BOXES DONE AND STORED IN AN ARRAY:

            box [] BOX = new box[2];

            BOX [0] = new box();
            BOX [1] = new box();

            // DETAILS OF BOX 1:
            BOX [0].length = 200;
            BOX [0].width = 10;
            BOX [0].depth = 5;
            BOX [0].Volume() ;

            // DETAILS OF BOX 2:
            BOX[1].length = 250;
            BOX[1].width = 15;
            BOX[1].depth = 10;
            BOX[1].Volume();

            Console.WriteLine("THE VOLUME OF ELEMENT BOX ONE IS: " + BOX[0].volume);
            Console.WriteLine("THE VOLUME OF ELEMENT BOX TWO IS: " + BOX[1].volume);
        }
    }
    public class box 
    {
       public double width;
       public double depth;
       public double length;
       public double area;
       public double volume;

       // method that calculates the volume for a box: 
       public void Volume()
       {
            volume = width * length * depth;
        }
    }
}
