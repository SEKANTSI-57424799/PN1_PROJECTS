﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUNDAY_13_SEPTEMBER_2020
{
    class Program
    {
        static void Main(string[] args)
        {
            string sname;
            string surname;
            string gender;
            int grade;
            int mark;

            Console.WriteLine(" PLEASE ENTER STUDENT NAME ");
                sname = Convert.ToString(Console.ReadLine());
            Console.WriteLine(" PLEASE ENTER STUDENT SURNAME ");
                surname = Convert.ToString(Console.ReadLine());
            Console.WriteLine(" PLEASE ENTER THE GENDER OF THE STUDENT ");
            gender = Convert.ToString(Console.ReadLine());
            Console.WriteLine(" PLEASE ENTER THE GRADE OF THE STUDENT ");
                grade = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" PLEASE ENTER THE STUDENT MARK ");
                mark = Convert.ToInt32(Console.ReadLine());


            Console.Write(" STUDENT NAME:  ");
                Console.WriteLine(sname);
            Console.Write(" STUDENT SURNAME: ");
             Console.WriteLine(surname);
            Console.Write(" STUDENT GENDER: ");
                Console.WriteLine(gender);
            Console.Write(" STUDENT GRADE: ");
                Console.WriteLine(grade);
            Console.Write(" STUDENT MARK: ");
                Console.WriteLine(mark);

            if (mark >= 95)
            {
                Console.WriteLine(" This is excellent ");
            }
            else if (mark >= 85)
            {
                Console.WriteLine(" This is very good ");
            }
            else if (mark >= 75)
            {
                Console.WriteLine(" This is good ");
            }
            else if (mark >= 65)
            {
                Console.WriteLine(" This is passionate ");
            }
            else if (mark >= 55)
            {
                Console.WriteLine(" This is fine ");
            }
            else {
                Console.WriteLine(" This is bad ");
            }
        }
    }
}
