﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REFERENCES
{
    class Program
    {
        static void Main(string[] args)
        {
            int var1=10;
            int var;
            Console.WriteLine("IN MAIN VAR IS {0}", var1);
            methodwithrefparam(out var); //notice use of out
            methodwithrefparam1(ref var1); //notice use of var
            Console.WriteLine("IN MAIN VAR IS {0}", var);
        }
        public static void methodwithrefparam1(ref int param)
        {
            param = 888;
            Console.WriteLine("IN THE methodwithrefparam, param is {0}", param);
        }
        public static void methodwithrefparam(out int param)
        {
            param = 888;
            Console.WriteLine("IN THE methodwithrefparam, param is {0}", param);
        }
    }
}
