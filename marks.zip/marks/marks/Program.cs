﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marks
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" my first practical!!!! ");

            int a;
            int b;

            Console.WriteLine("ENTER A");
                a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ENTER B");
                b = Convert.ToInt32(Console.ReadLine());

            int sum = (a + b);
            int product = (a * b);

            Console.WriteLine( a + " and "+ b );
            Console.WriteLine(  " the sum is: " + sum );
            Console.WriteLine( " the product is: " + product );

            if (b > a){
                Console.WriteLine(b + "  is greater than " + a);
            }
            else if (b >= a){
                Console.WriteLine(a + " equal to " + b);
            }
            else {
                Console.WriteLine( a + " greater than" + b);
            }
        }
    }
}
