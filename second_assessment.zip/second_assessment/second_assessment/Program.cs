﻿using System;

namespace second_assesment
{

    class Program
    {
        //declaration of global variables
        public static String F_Name;
        public static String L_Name;
        public static int St_Age;
        public static int StudentNumber;

        static void Main(string[] args)
        {
            //question one
            student trump = new student();
            trump.setFirstName("moeti");
            trump.setLastName("tsepang");
            trump.setAge(16);
            trump.setStudentNumber(2020);
            trump.Display();

            //question two
            student New_Student = new student(F_Name, L_Name, St_Age, StudentNumber);
            Console.WriteLine("Please Enter Student Name");
            F_Name = Console.ReadLine();
            Console.WriteLine("Please Enter Student LastName");
            L_Name = Console.ReadLine();
            Console.WriteLine("Please Enter StudentAge");
            St_Age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please Enter StudentNumber");
            StudentNumber = Convert.ToInt32(Console.ReadLine());

            New_Student.setFirstName(F_Name);
            New_Student.setLastName(L_Name);
            New_Student.setAge(St_Age);
            New_Student.setStudentNumber(StudentNumber);

            New_Student.Display();

            //question three
            student ManyStudents = new student();
            Console.WriteLine("Enter Number Of Students Your Want");
            int len = Convert.ToInt32(Console.ReadLine());

            student[] MoreStudents = new student[len];

            for (int i = 0; i < len; i++)
            {
                MoreStudents[i] = new student();
            }

            for (int i = 0; i < len; i++)
            {
                Console.WriteLine("Please Enter Student FirstName");
                F_Name = Console.ReadLine();
                Console.WriteLine("Please Enter Student LastName");
                L_Name = Console.ReadLine();
                Console.WriteLine("Please Enter StudentAge");
                St_Age = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Please Enter StudentNumber");
                StudentNumber = Convert.ToInt32(Console.ReadLine());

                MoreStudents[i].setValues(F_Name, L_Name, St_Age, StudentNumber);
            }

            for (int i = 0; i < len; i++)
            {
                MoreStudents[i].Display();
            }

        }
    }
    public class student
    {
        private String F_Name;
        private String L_Name;
        private int St_Age;
        private int StudentNumber;



        public student()
        {
            F_Name = null;
            L_Name = null;
            St_Age = 16;
            StudentNumber = 2020;
        }

        public student(string firstName, string lastName, int age, int studentNumber)
        {
            F_Name = firstName;
            L_Name = lastName;
            St_Age = age;
            StudentNumber = studentNumber;
        }

        public void setFirstName(String firstname)
        {
            F_Name = firstname;

        }
        public void setLastName(String lastname)
        {
            L_Name = lastname;

        }

        public void setAge(int age)
        {
            St_Age = age;

        }

        public void setStudentNumber(int studentnumber)
        {
            StudentNumber = studentnumber;
        }


        public String getFirstName()
        {
            return F_Name;
        }
        public String getLastName()
        {
            return L_Name;
        }

        public int getAge()
        {
            return St_Age;
        }

        public int getStudentNumber()
        {
            return StudentNumber;
        }

        public void Display()
        {
            Console.WriteLine("FirstName: " + getFirstName());
            Console.WriteLine("LastName: " + getLastName());
            Console.WriteLine("Age: " + getAge());
            Console.WriteLine("Student Number: " + getStudentNumber());

        }
        public static void Greeet()
        {
            Console.WriteLine("Hello");

        }

        public void setValues(string firstName, string lastName, int age, int studentNumber)
        {
            F_Name = firstName;
            L_Name = lastName;
            St_Age = age;
            StudentNumber = studentNumber;
        }


    }
}
