﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARRAYS_CONTINUATION
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] name = new string[5];
            string [] mark = new string [5];
            string comments;
            for (int i = 0; i < mark.Length;i++ )
            {
                Console.WriteLine("ENTER THE STUDENTS NAMES: ");
                name[i] = Console.ReadLine();
            }
            for (int i = 0; i < mark.Length; i++)
            {
                Console.WriteLine("ENTER THE STUDENTS MARKS: ");
                mark[i] = Console.ReadLine();
            }
            Console.WriteLine("AS THE PRINCIPAL PROVIDE SOME COMMENTS: ");
            comments = Console.ReadLine();

            for (int i = 0; i < mark.Length; i++)
            {
                Console.Write("THE STUDENT NAME IS: {0} ", name[i], i + 1);
                Console.WriteLine("HIS/HER IS: {0} ", mark[i], i + 1);
            }
            Console.WriteLine("THE PRINCIPAL'S COMMENTS: ");
            Console.WriteLine(comments);
        }
    }
}
