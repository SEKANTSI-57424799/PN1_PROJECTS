CREATE DATABASE AfroMed_In_Patient_Private_Clinic;
use AfroMed_In_Patient_Private_Clinic;

create table Patients
(
	patiet_id int identity (1001, 2),
	full_names varchar(40),
	contact_number varchar(35),
	email_address varchar(35),
	banking_card varchar(45),
	constraint pk_patiet_id primary key (patiet_id)
);

create table nurses(
	nurse_id int identity (202, 1),
	full_names varchar(40),
	contact_number varchar(35),
	email_address varchar(35),
	Statuss varchar (25),
	patiet_id int,
	constraint pk_nurse_id primary key (nurse_id),
	constraint fk_patient_id foreign key (patiet_id) references patients (patiet_id)
);

create table Doctors(
	Doc_id int identity (20, 1),
	full_names varchar(40),
	contact_number varchar(35),
	email_address varchar(35),
	Statuss varchar (25),
	patiet_id int,
	constraint pk_Doc_id primary key (Doc_id),
	constraint fk_ppatient_id foreign key (patiet_id) references patients (patiet_id)
);

create table Beds(
	bed_code int identity (123,2),
	room_number varchar(20),
	Bed_status varchar(25),
	Constraint pk_bed_code primary key (bed_code)
);

create table Bookings(
	Booking_code int identity (1919, 2),
	patiet_id int,
	Doc_id int,
	nurse_id int, 
	bed_code int,
	Check_in_date datetime,
	check_out_date datetime,
	visit_description varchar(255),
	constraint pk_Booking_code primary key (Booking_code),
	constraint fk_ppt_id foreign key (patiet_id) references patients (patiet_id),
	constraint fk_Doc_id foreign key (Doc_id) references Doctors (Doc_id),
	constraint fk_bed_code foreign key (bed_code) references Beds (bed_code),
	constraint fk_nurse_id foreign key (nurse_id) references nurses (nurse_id)
);

