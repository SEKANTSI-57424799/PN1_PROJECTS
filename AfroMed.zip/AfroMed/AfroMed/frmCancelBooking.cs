﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AfroMed
{
    public partial class frmCancelBooking : Form
    {
        public frmCancelBooking()
        {
            InitializeComponent();
        }


        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnBcancel_Click(object sender, EventArgs e)
        {
            int booking = Convert.ToInt32(txtBk_Code.Text);
            int Doc_id = Convert.ToInt32(txtDoc_ID.Text);
            int nurse_id = Convert.ToInt32(txtNs_ID.Text);

            SqlConnection con = new SqlConnection("Data Source=DESKTOP-MBVDK9D;Initial Catalog=AfroMed_In_Patient_Private_Clinic;Integrated Security=True");
            SqlDataAdapter block = new SqlDataAdapter("DELETE FROM Bookings where Booking_code ='"+booking+"' ", con);
            SqlDataAdapter block1 = new SqlDataAdapter("DELETE FROM Doctors where Doc_id ='"+Doc_id+"' ", con);
            SqlDataAdapter block2 = new SqlDataAdapter("DELETE FROM nurses where nurse_id ='" + nurse_id + "' ", con);
            DataTable td = new DataTable();
            block.Fill(td);
            block1.Fill(td);
            block2.Fill(td);

            if (td.Rows[0][0].ToString() == "1")
            {
                MessageBox.Show("BOOKING CANCELLED !!!!!!!!!!!!");
            }
            else
            {
                MessageBox.Show("WRONG STAFFID!!!!!!!!!!!!!!!!");
            }
        }
    }
}
