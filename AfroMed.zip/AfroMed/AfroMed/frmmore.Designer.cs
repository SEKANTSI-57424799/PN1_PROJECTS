﻿namespace AfroMed
{
    partial class frmmore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLgt = new System.Windows.Forms.Button();
            this.btnVBookings = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtRoom = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBook = new System.Windows.Forms.Button();
            this.txtVD = new System.Windows.Forms.TextBox();
            this.txtCOD = new System.Windows.Forms.TextBox();
            this.txtC_In_D = new System.Windows.Forms.TextBox();
            this.txtB_code = new System.Windows.Forms.TextBox();
            this.txtN_id = new System.Windows.Forms.TextBox();
            this.txtD_id = new System.Windows.Forms.TextBox();
            this.txtP_id = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLgt
            // 
            this.btnLgt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLgt.Location = new System.Drawing.Point(774, 510);
            this.btnLgt.Name = "btnLgt";
            this.btnLgt.Size = new System.Drawing.Size(199, 49);
            this.btnLgt.TabIndex = 18;
            this.btnLgt.Text = "LOGOUT";
            this.btnLgt.UseVisualStyleBackColor = true;
            this.btnLgt.Click += new System.EventHandler(this.btnLgt_Click);
            // 
            // btnVBookings
            // 
            this.btnVBookings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVBookings.Location = new System.Drawing.Point(563, 514);
            this.btnVBookings.Name = "btnVBookings";
            this.btnVBookings.Size = new System.Drawing.Size(189, 45);
            this.btnVBookings.TabIndex = 17;
            this.btnVBookings.Text = "VIEWS";
            this.btnVBookings.UseVisualStyleBackColor = true;
            this.btnVBookings.Click += new System.EventHandler(this.btnVBookings_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.txtRoom);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(37, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(465, 408);
            this.panel1.TabIndex = 19;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnBook);
            this.panel2.Controls.Add(this.txtVD);
            this.panel2.Controls.Add(this.txtCOD);
            this.panel2.Controls.Add(this.txtC_In_D);
            this.panel2.Controls.Add(this.txtB_code);
            this.panel2.Controls.Add(this.txtN_id);
            this.panel2.Controls.Add(this.txtD_id);
            this.panel2.Controls.Add(this.txtP_id);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Location = new System.Drawing.Point(525, 51);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(448, 408);
            this.panel2.TabIndex = 20;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(77, 256);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(316, 36);
            this.btnAdd.TabIndex = 7;
            this.btnAdd.Text = "ADD ";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtRoom
            // 
            this.txtRoom.Location = new System.Drawing.Point(77, 199);
            this.txtRoom.Multiline = true;
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.Size = new System.Drawing.Size(316, 35);
            this.txtRoom.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(73, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "ROOM NUMBER";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(157, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "ADD BED";
            // 
            // btnBook
            // 
            this.btnBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBook.Location = new System.Drawing.Point(172, 341);
            this.btnBook.Name = "btnBook";
            this.btnBook.Size = new System.Drawing.Size(269, 46);
            this.btnBook.TabIndex = 31;
            this.btnBook.Text = "Book";
            this.btnBook.UseVisualStyleBackColor = true;
            this.btnBook.Click += new System.EventHandler(this.btnBook_Click);
            // 
            // txtVD
            // 
            this.txtVD.Location = new System.Drawing.Point(172, 286);
            this.txtVD.Multiline = true;
            this.txtVD.Name = "txtVD";
            this.txtVD.Size = new System.Drawing.Size(269, 28);
            this.txtVD.TabIndex = 30;
            // 
            // txtCOD
            // 
            this.txtCOD.Location = new System.Drawing.Point(172, 254);
            this.txtCOD.Multiline = true;
            this.txtCOD.Name = "txtCOD";
            this.txtCOD.Size = new System.Drawing.Size(269, 28);
            this.txtCOD.TabIndex = 29;
            // 
            // txtC_In_D
            // 
            this.txtC_In_D.Location = new System.Drawing.Point(172, 218);
            this.txtC_In_D.Multiline = true;
            this.txtC_In_D.Name = "txtC_In_D";
            this.txtC_In_D.Size = new System.Drawing.Size(269, 28);
            this.txtC_In_D.TabIndex = 28;
            // 
            // txtB_code
            // 
            this.txtB_code.Location = new System.Drawing.Point(172, 181);
            this.txtB_code.Multiline = true;
            this.txtB_code.Name = "txtB_code";
            this.txtB_code.Size = new System.Drawing.Size(269, 28);
            this.txtB_code.TabIndex = 27;
            // 
            // txtN_id
            // 
            this.txtN_id.Location = new System.Drawing.Point(172, 148);
            this.txtN_id.Multiline = true;
            this.txtN_id.Name = "txtN_id";
            this.txtN_id.Size = new System.Drawing.Size(269, 28);
            this.txtN_id.TabIndex = 26;
            // 
            // txtD_id
            // 
            this.txtD_id.Location = new System.Drawing.Point(172, 106);
            this.txtD_id.Multiline = true;
            this.txtD_id.Name = "txtD_id";
            this.txtD_id.Size = new System.Drawing.Size(269, 28);
            this.txtD_id.TabIndex = 25;
            // 
            // txtP_id
            // 
            this.txtP_id.Location = new System.Drawing.Point(172, 70);
            this.txtP_id.Multiline = true;
            this.txtP_id.Name = "txtP_id";
            this.txtP_id.Size = new System.Drawing.Size(269, 28);
            this.txtP_id.TabIndex = 24;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 289);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(140, 20);
            this.label8.TabIndex = 23;
            this.label8.Text = "Visit Description";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 20);
            this.label7.TabIndex = 22;
            this.label7.Text = "CheckOutDate";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 20);
            this.label6.TabIndex = 21;
            this.label6.Text = "CheckInDate";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 20);
            this.label5.TabIndex = 20;
            this.label5.Text = "Bed Code";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 20);
            this.label4.TabIndex = 19;
            this.label4.Text = "NurseID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "DoctorID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 20);
            this.label9.TabIndex = 17;
            this.label9.Text = "PatientID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(437, 31);
            this.label10.TabIndex = 16;
            this.label10.Text = "ADD PATIENTS BOOKINGS . . .";
            // 
            // frmmore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.ClientSize = new System.Drawing.Size(1001, 571);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnLgt);
            this.Controls.Add(this.btnVBookings);
            this.Name = "frmmore";
            this.Text = "frmmore";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLgt;
        private System.Windows.Forms.Button btnVBookings;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtRoom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBook;
        private System.Windows.Forms.TextBox txtVD;
        private System.Windows.Forms.TextBox txtCOD;
        private System.Windows.Forms.TextBox txtC_In_D;
        private System.Windows.Forms.TextBox txtB_code;
        private System.Windows.Forms.TextBox txtN_id;
        private System.Windows.Forms.TextBox txtD_id;
        private System.Windows.Forms.TextBox txtP_id;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}