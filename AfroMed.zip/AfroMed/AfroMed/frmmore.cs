﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AfroMed
{
    public partial class frmmore : Form
    {
        public frmmore()
        {
            InitializeComponent();
        }

        private void btnAddBeds_Click(object sender, EventArgs e)
        {

        }

        private void btnVBookings_Click(object sender, EventArgs e)
        {
            frmViews fv = new frmViews();
            fv.Show();
            this.Hide();
        }

        private void btnAVN_Click(object sender, EventArgs e)
        {

        }

        private void btnVAD_Click(object sender, EventArgs e)
        {

        }

        private void btnAddBookings_Click(object sender, EventArgs e)
        {

        }

        private void btnLgt_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-MBVDK9D;Initial Catalog=AfroMed_In_Patient_Private_Clinic;Integrated Security=True");
                con.Open();

                string room_number = txtRoom.Text;
                string Bed_status = "Available";

                SqlCommand cmd = new SqlCommand("Insert into beds (room_number,Bed_status) values ( '" + room_number + "', '" + Bed_status + "')", con);
                int count = cmd.ExecuteNonQuery();
                if (count != 0)
                {
                    MessageBox.Show(" SUCCESSFUL!!", "AfroMed");
                }
                else
                {
                    MessageBox.Show("ADDITION ERROR!!!!!!", "AfroMed");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.ToString(), "INSTERTION FAILED", 0);
            }
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-MBVDK9D;Initial Catalog=AfroMed_In_Patient_Private_Clinic;Integrated Security=True");
                con.Open();

                int patiet_id = Convert.ToInt32(txtP_id.Text);
                int Doc_id = Convert.ToInt32(txtD_id.Text); ;
                int nurse_id = Convert.ToInt32(txtN_id.Text); ;
                int bed_code = Convert.ToInt32(txtB_code.Text); ;
                DateTime Check_in_date = Convert.ToDateTime(txtC_In_D.Text);
                DateTime Check_out_date = Convert.ToDateTime(txtCOD.Text); ;
                string visit_description = txtVD.Text;

                SqlCommand cmd = new SqlCommand("Insert into Bookings (patient_id,Doc_id,nurse_id,bed_code,Check_in_date,Check_out_date,visit_description) values ( '" + patiet_id + "', '" + Doc_id + "', '" + nurse_id + "', '" + bed_code + "', '" + Check_in_date + "', '" + Check_out_date + "', '" + visit_description + "')", con);
                int count = cmd.ExecuteNonQuery();
                if (count != 0)
                {
                    MessageBox.Show(" SUCCESSFUL!!", "AfroMed");
                }
                else
                {
                    MessageBox.Show("ADDITION ERROR!!!!!!", "AfroMed");
                }

            }
            catch (Exception error)
            {
                MessageBox.Show(error.ToString(), "INSTERTION FAILED", 0);
            }
        }
    }
}
