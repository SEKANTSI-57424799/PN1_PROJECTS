﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AfroMed
{
    public partial class admin : Form
    {
        public admin()
        {
            InitializeComponent();
        }


        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void btnCheckIn_Click(object sender, EventArgs e)
        {

        }

        private void btnLgt_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-MBVDK9D;Initial Catalog=AfroMed_In_Patient_Private_Clinic;Integrated Security=True");
                con.Open();

                string name = txtnames.Text;
                string phonenumber = txtnumber.Text;
                string email = txtemail.Text;
                string banking = cmbBanking.SelectedItem.ToString();

                SqlCommand cmd = new SqlCommand("Insert into Patients (full_names,contact_number,email_address,banking_card) values ('" + name + "', '" + phonenumber + "', '" + email + "', '" + banking + "')", con);
                int count = cmd.ExecuteNonQuery();
                if (count != 0)
                {
                    MessageBox.Show("ACCOUNT CREATION SUCCESSFUL!!", "AfroMed");
                }
                else
                {
                    MessageBox.Show("ACCOUNT CREATION ERROR!!!!!!", "AfroMed");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.ToString(), "INSTERTION FAILED", 0);
            }


        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-MBVDK9D;Initial Catalog=AfroMed_In_Patient_Private_Clinic;Integrated Security=True");
                con.Open();

                string name = txtFnames.Text;
                string contact_number = txtContact.Text;
                string email = textBox1.Text;
                string Statuss = "Available";
                

                SqlCommand cmd = new SqlCommand("Insert into Doctors (full_names,contact_number,email_address,Statuss) values ('" + name + "', '" + contact_number + "', '" + email + "', '" + Statuss + "')", con);
                int count = cmd.ExecuteNonQuery();
                if (count != 0)
                {
                    MessageBox.Show("DOCTOR ADDITION SUCCESSFUL!!", "AfroMed");
                }
                else
                {
                    MessageBox.Show("DOCTOR ADDITION ERROR!!!!!!", "AfroMed");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.ToString(), "DOCTOR ADDITION FAILED", 0);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-MBVDK9D;Initial Catalog=AfroMed_In_Patient_Private_Clinic;Integrated Security=True");
                con.Open();

                string name = txtFnames.Text;
                string contact_number = txtContact.Text;
                string email = textBox1.Text;
                string Statuss = "Available";

                SqlCommand cmd = new SqlCommand("Insert into nurses (full_names,contact_number,email_address,Statuss) values ('" + name + "', '" + contact_number + "', '" + email + "', '" + Statuss + "')", con);
                int count = cmd.ExecuteNonQuery();
                if (count != 0)
                {
                    MessageBox.Show("NURSE ADDITION SUCCESSFUL!!", "AfroMed");
                }
                else
                {
                    MessageBox.Show("NURSE ADDITION ERROR!!!!!!", "AfroMed");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.ToString(), "NURSE ADDITION FAILED", 0);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmmore fm = new frmmore();
            fm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
