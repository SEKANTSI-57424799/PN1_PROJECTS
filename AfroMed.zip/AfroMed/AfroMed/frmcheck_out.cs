﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AfroMed
{
    public partial class frmcheck_out : Form
    {
        public frmcheck_out()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBcancel_Click(object sender, EventArgs e)
        {
            int bedcode = Convert.ToInt32(txtBd_Code.Text);
            int Doc_id = Convert.ToInt32(txtDoc_ID.Text);
            int nurse_id = Convert.ToInt32(txtNs_ID.Text);
            int Booking_code = Convert.ToInt32(txtBooking_code.Text);
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-MBVDK9D;Initial Catalog=AfroMed_In_Patient_Private_Clinic;Integrated Security=True");
                SqlDataAdapter Update = new SqlDataAdapter("Delete from Bookings where Booking_code ='" + Booking_code + "' ", con);
                SqlDataAdapter Update1 = new SqlDataAdapter("Update Beds set Bed_status = 'Available' where bed_code ='" + bedcode + "' ", con);
                SqlDataAdapter Update2 = new SqlDataAdapter("Update Doctors set Statuss = 'Available' where Doc_id ='" + Doc_id + "' ", con);
                SqlDataAdapter Update3 = new SqlDataAdapter("Update nurses set Statuss = 'Available' where nurse_id ='" + nurse_id + "' ", con);
                DataTable td = new DataTable();

                Update.Fill(td);
                Update1.Fill(td);
                Update2.Fill(td);
                if (td.Rows[0][0].ToString() == "1")
                {
                    MessageBox.Show("CHECK OUT SUCCESSFUL !!!!!!!!!!!!");
                }
                else
                {
                    MessageBox.Show("WRONG IDENTITIES!!!!!!!!!!!!!!!!");
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(" QUERY EXECUTED  ", " AFROMED ");
            }
        }

        private void btnClosure_Click(object sender, EventArgs e)
        {
            frmViews vb = new frmViews();
            vb.Show();
            this.Hide();
        }
    }
}
