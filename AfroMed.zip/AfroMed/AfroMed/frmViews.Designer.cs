﻿namespace AfroMed
{
    partial class frmViews
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgViewAvailableDoctors = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.dgViewAvailableNursess = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.dgViewBookings = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCkOut = new System.Windows.Forms.Button();
            this.btnCkIn = new System.Windows.Forms.Button();
            this.btnCancelBookings = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewAvailableDoctors)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewAvailableNursess)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewBookings)).BeginInit();
            this.SuspendLayout();
            // 
            // dgViewAvailableDoctors
            // 
            this.dgViewAvailableDoctors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgViewAvailableDoctors.Location = new System.Drawing.Point(12, 46);
            this.dgViewAvailableDoctors.Name = "dgViewAvailableDoctors";
            this.dgViewAvailableDoctors.Size = new System.Drawing.Size(517, 172);
            this.dgViewAvailableDoctors.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(309, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "LIST OF AVAILABLE DOCTORS";
            // 
            // dgViewAvailableNursess
            // 
            this.dgViewAvailableNursess.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgViewAvailableNursess.Location = new System.Drawing.Point(559, 46);
            this.dgViewAvailableNursess.Name = "dgViewAvailableNursess";
            this.dgViewAvailableNursess.Size = new System.Drawing.Size(577, 172);
            this.dgViewAvailableNursess.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(555, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(292, 24);
            this.label2.TabIndex = 8;
            this.label2.Text = "LIST OF AVAILABLE NURSES";
            // 
            // dgViewBookings
            // 
            this.dgViewBookings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgViewBookings.Location = new System.Drawing.Point(12, 264);
            this.dgViewBookings.Name = "dgViewBookings";
            this.dgViewBookings.Size = new System.Drawing.Size(1124, 241);
            this.dgViewBookings.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(405, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(315, 24);
            this.label3.TabIndex = 10;
            this.label3.Text = "LIST OF AVAILABLE BOOKINGS";
            // 
            // btnCkOut
            // 
            this.btnCkOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCkOut.Location = new System.Drawing.Point(864, 521);
            this.btnCkOut.Name = "btnCkOut";
            this.btnCkOut.Size = new System.Drawing.Size(130, 36);
            this.btnCkOut.TabIndex = 17;
            this.btnCkOut.Text = "CHECK OUT";
            this.btnCkOut.UseVisualStyleBackColor = true;
            this.btnCkOut.Click += new System.EventHandler(this.btnCkOut_Click_1);
            // 
            // btnCkIn
            // 
            this.btnCkIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCkIn.Location = new System.Drawing.Point(704, 521);
            this.btnCkIn.Name = "btnCkIn";
            this.btnCkIn.Size = new System.Drawing.Size(129, 37);
            this.btnCkIn.TabIndex = 16;
            this.btnCkIn.Text = "CHECK IN";
            this.btnCkIn.UseVisualStyleBackColor = true;
            this.btnCkIn.Click += new System.EventHandler(this.btnCkIn_Click_1);
            // 
            // btnCancelBookings
            // 
            this.btnCancelBookings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelBookings.Location = new System.Drawing.Point(504, 521);
            this.btnCancelBookings.Name = "btnCancelBookings";
            this.btnCancelBookings.Size = new System.Drawing.Size(161, 37);
            this.btnCancelBookings.TabIndex = 15;
            this.btnCancelBookings.Text = "CANCEL BOOKINGS";
            this.btnCancelBookings.UseVisualStyleBackColor = true;
            this.btnCancelBookings.Click += new System.EventHandler(this.btnCancelBookings_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(1029, 520);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(107, 35);
            this.btnClose.TabIndex = 14;
            this.btnClose.Text = "CLOSE";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click_1);
            // 
            // frmViews
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.ClientSize = new System.Drawing.Size(1138, 588);
            this.Controls.Add(this.btnCkOut);
            this.Controls.Add(this.btnCkIn);
            this.Controls.Add(this.btnCancelBookings);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgViewBookings);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgViewAvailableNursess);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgViewAvailableDoctors);
            this.Name = "frmViews";
            this.Text = "frmViews";
            this.Load += new System.EventHandler(this.frmViews_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgViewAvailableDoctors)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewAvailableNursess)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewBookings)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgViewAvailableDoctors;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgViewAvailableNursess;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgViewBookings;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCkOut;
        private System.Windows.Forms.Button btnCkIn;
        private System.Windows.Forms.Button btnCancelBookings;
        private System.Windows.Forms.Button btnClose;
    }
}