﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AfroMed
{
    public partial class frmViews : Form
    {
        public frmViews()
        {
            InitializeComponent();
        }

        private void btnView_Click(object sender, EventArgs e)
        {

        }

        private void frmViews_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-MBVDK9D;Initial Catalog=AfroMed_In_Patient_Private_Clinic;Integrated Security=True");
            SqlDataAdapter adp;

            DataSet ds = new DataSet();
            DataTable dt;
            DataRow dr;
            //CODE FOR VIEWING DOCTORS
            adp = new SqlDataAdapter();
            adp.SelectCommand = new SqlCommand("Select * from Doctors where Statuss = 'Available' ", con);
            adp.Fill(ds, "Doctors");
            dt = ds.Tables["Doctors"];
            dr = dt.Rows[0];

            dgViewAvailableDoctors.DataSource = ds.Tables["Doctors"];

            //CODE FOR VIEWING NURSES
            adp = new SqlDataAdapter();
            adp.SelectCommand = new SqlCommand("Select * from nurses where Statuss = 'Available' ", con);
            adp.Fill(ds, "nurses");
            dt = ds.Tables["nurses"];
            dr = dt.Rows[0];

            dgViewAvailableNursess.DataSource = ds.Tables["nurses"];

            //CODE FOR VIEWING BOOKINGS
            adp = new SqlDataAdapter();
            adp.SelectCommand = new SqlCommand("Select * from Bookings", con);
            adp.Fill(ds, "Bookings");
            dt = ds.Tables["Bookings"];
            dr = dt.Rows[0];

            dgViewBookings.DataSource = ds.Tables["Bookings"];
        }


        private void btnCancelBookings_Click(object sender, EventArgs e)
        {
            frmCancelBooking n = new frmCancelBooking();
            n.Show();
            this.Hide();
        }


        private void btnClose_Click_1(object sender, EventArgs e)
        {
            admin ap = new admin();
            ap.Show();
            this.Hide();
        }

        private void btnCkOut_Click_1(object sender, EventArgs e)
        {
            frmcheck_out co = new frmcheck_out();
            co.Show();
            this.Hide();
        }

        private void btnCkIn_Click_1(object sender, EventArgs e)
        {
            frmcheck_in ci = new frmcheck_in();
            ci.Show();
            this.Hide();
        }
    }
}
